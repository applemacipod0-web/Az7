# Compound V Mod — The Boys | Minecraft Forge 1.20.1

---

## 🧬 V1 SERUMU — 3 DOZ SİSTEMİ

V1 serumu **maksimum 3 kez** içilebilir. Her doz daha güçlü etkiler sağlar.

### 1. Doz — Temel Güçler
| Güç | Kaynak | Notlar |
|-----|--------|--------|
| **Ölümsüze Yakın Dayanıklılık** | Compound V | Zorunlu — Resistance 5, +20 can, ateş bağışıklığı |
| **Süper Güç** | Compound V | Zorunlu — Güç 5 |
| Lazer Gözler (H tuşu) | Homelander | %20 şans |
| Uçma (G tuşu) | Homelander | %20 şans |
| Yıldırım (N tuşu) | Stormfront | %20 şans |
| Sürat + Ezme | A-Train | %40 şans |
| Hızlı İyileşme | Kimiko | %40 şans |
| Elektromanyetik Alan | Stormfront | %40 şans |
| Stormfront Kalkanı | Stormfront | %20 şans |
| **Soldier Boy Paketi** (Boyut + Nükleer Patlama Z) | Soldier Boy | %20 şans, ikisi birlikte gelir |

> ⚠ **Stormfront güçleri (Yıldırım Kontrolü) V1'e gelmez** — ayrı serum gerektirir.

---

### 2. Doz — Güçlendirme
| Sonuç | Şans |
|-------|------|
| **Mevcut güçler Seviye 2'ye yükselir** (Resistance 6, Güç 6, +30 can) | %80 |
| **Yeni rastgele bir güç kazanırsın** | %20 |

### 3. Doz — Maksimum
| Sonuç | Şans |
|-------|------|
| **Güçler MAX Seviye 3'e yükselir** (Resistance 7, Güç 7, +40 can) | %80 |
| **Yeni rastgele bir güç kazanırsın** | %20 |

> ❌ **4. içişte etki olmaz.** Ekrana uyarı çıkar.

---

## 🎮 TUŞ ATAMALARI

| Tuş | Güç | Şart |
|-----|-----|------|
| **Z** | ☢ Nükleer Patlama — 15 blok yarıçap, kendin hasar almaz | Soldier Boy paketi lazım |
| **G** | ✈ Uçma Aç/Kapat | Uçma gücü lazım |
| **H** | 🔴 Lazer Göz | Lazer gücü lazım |
| **N** | ⚡ Yıldırım Saldırısı | Yıldırım gücü lazım |

*Tuşları Ayarlar → Kontroller → "Compound V - Süper Güçler" kategorisinden değiştirebilirsin.*

---

## 🔨 ÜRETİM REHBERİ

> ⚠ **V1 Serumu artık Crafting Table'dan YAPILMAZ.** Sadece **Serum Maker** bloğunda üretilir.

### Stabilizör
```
E E E
E D E    E = Ender İnci    D = Ejderha Nefesi
E E E
```

### Ham Compound V
```
N G N
G B G    N = Nether Yıldızı    G = Ghast Gözyaşı    B = Işınak (Beacon)
N G N
```

### Serum Maker (Blok)
```
I F I
F R F    I = Demir    F = Fırın    R = Redstone Bloğu
I F I
```

### V1 Serumu — Serum Maker'da üret
| Slot | Malzeme |
|------|---------|
| Sol | Ham Compound V |
| Orta | Stabilizör |
| Sağ | Elmas |

---

## 🎒 CREATIVE SEKMELER

| Sekme | İçerik |
|-------|--------|
| **Compound V — Serumlar** | V1 Serumu, Ham Compound V, Stabilizör |
| **Compound V — Makineler** | Serum Maker bloğu |

---

## ⚔ ÖZEL MEKANİKLER

### Soldier Boy — Nükleer Patlama (Z)
- **Kendinden** patlama yapar, uzaktan değil
- 15 blok yarıçapındaki **tüm canlılar** hasar alır (hayvanlar dahil)
- Diğer oyuncular da hasar alır
- **Patlamayı yapan oyuncu hasar ALMAZ**
- Hafif geri tepme efekti olur (havaya fırlar)

### A-Train — Sürat + Ezme
- Hareket halindeyken herhangi bir canlının üstüne girince **anında öldürür**
- Ezerken **kırmızı kan partikülleri** çıkar
- Diğer oyuncular ezme ile ölmez (sadece canlılar)

### Elektromanyetik Alan (Stormfront)
- Çevredeki **sadece düşman moblara** (Monster) her birkaç saniyede hasar verir
- Yanındaki hayvanlar, köylüler ve oyuncular hasar almaz

---

## 🔧 KURULUM

1. **Forge 1.20.1** yükle — [forge resmi sitesi](https://files.minecraftforge.net)
2. `.jar` dosyasını `mods/` klasörüne koy
3. Oyunu başlat

## 🛠 DERLEME

```bash
./gradlew build
```
Jar dosyası `build/libs/` klasöründe oluşur.

---

## 📋 GELECEK GÜNCELLEMELER

- **Compound V** serumu — Homelander, A-Train, The Deep, Starlight, Kimiko güçleri
- **V24** serumu — Geçici güçlendirme serumu
- **Stormfront Serumu** — Yıldırım Kontrolü dahil tam Stormfront paketi
- **Modern Compound V** — Gelişmiş formül, daha az rastgelelik
