package com.compoundv.mod;

import com.compoundv.mod.block.ModBlocks;
import com.compoundv.mod.blockentity.ModBlockEntities;
import com.compoundv.mod.capability.SuperPowerCapability;
import com.compoundv.mod.effect.ModEffects;
import com.compoundv.mod.event.PlayerEventHandler;
import com.compoundv.mod.event.KeyInputHandler;
import com.compoundv.mod.item.ModItems;
import com.compoundv.mod.menu.ModMenuTypes;
import com.compoundv.mod.network.PacketHandler;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Mod(CompoundVMod.MOD_ID)
public class CompoundVMod {

    public static final String MOD_ID = "compoundv";
    public static final Logger LOGGER = LogManager.getLogger();

    public CompoundVMod() {
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();

        ModItems.ITEMS.register(modEventBus);
        ModItems.CREATIVE_TABS.register(modEventBus);
        ModBlocks.BLOCKS.register(modEventBus);
        ModBlockEntities.BLOCK_ENTITIES.register(modEventBus);
        ModMenuTypes.MENUS.register(modEventBus);
        ModEffects.EFFECTS.register(modEventBus);

        modEventBus.addListener(this::commonSetup);

        MinecraftForge.EVENT_BUS.register(new PlayerEventHandler());
        MinecraftForge.EVENT_BUS.register(new SuperPowerCapability.Provider());
        MinecraftForge.EVENT_BUS.register(new KeyInputHandler());
    }

    private void commonSetup(final FMLCommonSetupEvent event) {
        event.enqueueWork(() -> {
            PacketHandler.register();
            SuperPowerCapability.register();
        });
    }

    public static ResourceLocation rl(String path) {
        return new ResourceLocation(MOD_ID, path);
    }
}
