package com.compoundv.mod.event;

import com.compoundv.mod.capability.SuperPowerCapability;
import com.compoundv.mod.util.SuperPower;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.phys.AABB;
import com.compoundv.mod.network.PacketHandler;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.entity.living.LivingDamageEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.network.PacketDistributor;

import java.util.List;
import java.util.Random;

public class PlayerEventHandler {

    private static final Random RANDOM = new Random();

    // ===================== TICK HANDLER =====================
    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.START) return;
        Player player = event.player;

        SuperPowerCapability.get(player).ifPresent(cap -> {
            if (!cap.isPowerEnabled()) return;

            // === ÖLÜMSÜZE YAKIN DAYANIKLILIK ===
            if (cap.hasPower(SuperPower.NEAR_IMMORTALITY)) {
                applyNearImmortality(player, cap);
            }

            // === SÜPER GÜÇ ===
            if (cap.hasPower(SuperPower.SUPER_STRENGTH)) {
                applyStrength(player, cap);
            }

            // === UÇMA ===
            if (cap.hasPower(SuperPower.FLIGHT)) {
                if (cap.isFlying()) {
                    applyFlight(player);
                } else {
                    // Uçma kapalıysa yerçekimini geri ver
                    if (player.isNoGravity()) {
                        player.setNoGravity(false);
                        player.getAbilities().mayfly = false;
                        player.getAbilities().flying = false;
                        player.onUpdateAbilities();
                    }
                }
            }

            // === SÜRAT - ÇARPMA HASARI ===
            if (cap.hasPower(SuperPower.SUPER_SPEED) && !player.level().isClientSide()) {
                applySpeedAndDamage(player, cap);
            }

            // === YENİLEME ===
            if (cap.hasPower(SuperPower.REGENERATION)) {
                if (player.tickCount % 20 == 0) {
                    player.heal(1.0f);
                }
            }

            // === STORMFRONT KALKANI ===
            if (cap.hasPower(SuperPower.STORMFRONT_SHIELD)) {
                if (player.tickCount % 40 == 0) {
                    player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 60, 1, false, false));
                }
            }

            // === ELEKTROMANYETİK ALAN ===
            if (cap.hasPower(SuperPower.ELECTROMAGNETIC)) {
                if (player.tickCount % 60 == 0 && !player.level().isClientSide()) {
                    applyElectromagneticField(player);
                }
            }

            // === SOLDIER BOY BOYUTU ===
            // Not: Forge 1.20.1'de oyuncu boyutunu doğrudan değiştirmek mümkün değildir;
            // bu alan gelecekteki bir render hook için korunmaktadır.
            // Şimdilik görsel mesaj ile bildirim verilir, NBT'de sizeMultiplier saklanır.
        });
    }

    // ===================== ÖLÜMSÜZE YAKIN DAYANIKLILIK =====================
    private void applyNearImmortality(Player player, SuperPowerCapability cap) {
        int amp = cap.getPowerAmplifier(); // 0=normal, 1=güçlenmiş(2.doz), 2=max(3.doz)

        // Direnç: amp=0 → Resistance 5, amp=1 → Resistance 6, amp=2 → Resistance 7
        player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 40, 4 + amp, false, false));
        player.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 40, 0, false, false));

        // Yenilenme: amp arttıkça daha hızlı iyileşme
        if (player.getHealth() < player.getMaxHealth() * (0.3f + amp * 0.15f)) {
            player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 40, 2 + amp, false, false));
        }

        // Maksimum can artışı: amp=0 → +20 can, amp=1 → +30 can, amp=2 → +40 can
        int healthBoostLevel = 9 + amp * 5; // 9, 14, 19
        if (!player.hasEffect(MobEffects.HEALTH_BOOST) ||
            player.getEffect(MobEffects.HEALTH_BOOST).getAmplifier() < healthBoostLevel) {
            player.addEffect(new MobEffectInstance(MobEffects.HEALTH_BOOST, 60, healthBoostLevel, false, false));
        }
    }

    // ===================== SÜPER GÜÇ =====================
    private void applyStrength(Player player, SuperPowerCapability cap) {
        int amp = cap.getPowerAmplifier(); // 0=normal, 1=güçlenmiş, 2=max
        // Hasar: amp=0 → Güç 5, amp=1 → Güç 6, amp=2 → Güç 7
        player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 40, 4 + amp, false, false));
    }

    // ===================== UÇMA =====================
    private void applyFlight(Player player) {
        player.setNoGravity(true);
        player.resetFallDistance();
        player.getAbilities().mayfly = true;
        player.getAbilities().flying = true;
        player.onUpdateAbilities();
    }

    // ===================== SÜRAT + EZME =====================
    private void applySpeedAndDamage(Player player, SuperPowerCapability cap) {
        player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 40, 8, false, false)); // Hız 9

        // Hareket ediyorsa ezme aktif (yavaş yürüme dahil)
        if (player.getDeltaMovement().horizontalDistance() > 0.05) {
            AABB hitBox = player.getBoundingBox().inflate(0.3);
            List<LivingEntity> nearby = player.level().getEntitiesOfClass(
                LivingEntity.class, hitBox,
                e -> e != player && !(e instanceof Player p && p.isCreative())
            );

            for (LivingEntity entity : nearby) {
                if (!entity.isDeadOrDying()) {
                    // A-Train gibi — üstüne basınca anında öldür
                    entity.hurt(player.level().damageSources().playerAttack(player), Float.MAX_VALUE);
                    entity.kill();

                    // Kırmızı kan partikülleri (server → client gönder)
                    if (player.level() instanceof net.minecraft.server.level.ServerLevel serverLevel) {
                        serverLevel.sendParticles(
                            net.minecraft.core.particles.ParticleTypes.DAMAGE_INDICATOR,
                            entity.getX(), entity.getY() + 0.5, entity.getZ(),
                            20,   // adet
                            0.3, 0.5, 0.3,  // spread
                            0.1   // hız
                        );
                        serverLevel.sendParticles(
                            net.minecraft.core.particles.ParticleTypes.CRIT,
                            entity.getX(), entity.getY() + 0.5, entity.getZ(),
                            15,
                            0.4, 0.4, 0.4,
                            0.2
                        );
                    }
                }
            }
        }
    }

    // ===================== ELEKTROMANYETİK ALAN =====================
    private void applyElectromagneticField(Player player) {
        if (!(player.level() instanceof ServerLevel serverLevel)) return;
        AABB range = player.getBoundingBox().inflate(4.0);
        List<LivingEntity> nearby = player.level().getEntitiesOfClass(
            LivingEntity.class, range,
            e -> e != player && !(e instanceof Player) &&
                 e instanceof net.minecraft.world.entity.monster.Monster
        );
        for (LivingEntity entity : nearby) {
            entity.hurt(player.level().damageSources().lightningBolt(), 4.0f);
        }
    }

    // ===================== HASAR AZALTMA (ÖLÜMSÜZLÜK) =====================
    @SubscribeEvent
    public void onLivingDamage(LivingDamageEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;

        SuperPowerCapability.get(player).ifPresent(cap -> {
            if (!cap.isPowerEnabled()) return;

            if (cap.hasPower(SuperPower.NEAR_IMMORTALITY)) {
                // Ölümsüze yakın: Hasarı %95 azalt, minimum 0.1 hasar
                float original = event.getAmount();
                float reduced = Math.max(0.1f, original * 0.05f);
                event.setAmount(reduced);

                // Saldıran varlığa geri hasar ver (Stormfront kalkanı ile)
                if (cap.hasPower(SuperPower.STORMFRONT_SHIELD)) {
                    Entity source = event.getSource().getEntity();
                    if (source instanceof LivingEntity attacker) {
                        attacker.hurt(player.level().damageSources().magic(), original * 0.5f);
                    }
                }
            }
        });
    }

    // ===================== PLAYER KOPYA (RESPAWN) =====================
    @SubscribeEvent
    public void onPlayerClone(PlayerEvent.Clone event) {
        if (!event.isWasDeath()) return;
        Player original = event.getOriginal();
        Player newPlayer = event.getEntity();

        original.reviveCaps();
        SuperPowerCapability.get(original).ifPresent(oldCap -> {
            SuperPowerCapability.get(newPlayer).ifPresent(newCap -> {
                newCap.deserializeNBT(oldCap.serializeNBT());
            });
        });
        original.invalidateCaps();
    }
}
