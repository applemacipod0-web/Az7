package com.compoundv.mod.event;

import com.compoundv.mod.capability.SuperPowerCapability;
import com.compoundv.mod.util.SuperPower;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.phys.AABB;
import com.compoundv.mod.network.PacketHandler;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.entity.living.LivingDamageEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.network.PacketDistributor;
import com.compoundv.mod.network.SyncPowersPacket;

import java.util.List;
import java.util.Random;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;

public class PlayerEventHandler {

    private static final Random RANDOM = new Random();

    // ===================== TICK HANDLER =====================
    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.START) return;
        Player player = event.player;

        SuperPowerCapability.get(player).ifPresent(cap -> {
            if (!cap.isPowerEnabled()) return;

            // === ÖLÜMSÜZE YAKIN DAYANIKLILIK ===
            if (cap.hasPower(SuperPower.NEAR_IMMORTALITY)) {
                applyNearImmortality(player, cap);
            }

            // === SÜPER GÜÇ ===
            if (cap.hasPower(SuperPower.SUPER_STRENGTH)) {
                applyStrength(player, cap);
            }

            // === UÇMA ===
            if (cap.hasPower(SuperPower.FLIGHT)) {
                if (cap.isFlying()) {
                    applyFlight(player);
                } else {
                    if (player.isNoGravity()) {
                        player.setNoGravity(false);
                        player.getAbilities().mayfly = false;
                        player.getAbilities().flying = false;
                        player.onUpdateAbilities();
                    }
                }
            }

            // === SÜRAT - ÇARPMA HASARI ===
            if (cap.hasPower(SuperPower.SUPER_SPEED) && !player.level().isClientSide()) {
                applySpeedAndDamage(player, cap);
            }

            // === YENİLEME ===
            if (cap.hasPower(SuperPower.REGENERATION)) {
                if (player.tickCount % 20 == 0) {
                    player.heal(1.0f);
                }
            }

            // === STORMFRONT KALKANI ===
            if (cap.hasPower(SuperPower.STORMFRONT_SHIELD)) {
                if (player.tickCount % 40 == 0) {
                    player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 60, 1, false, false));
                }
            }

            // === ELEKTROMANYETİK ALAN ===
            if (cap.hasPower(SuperPower.ELECTROMAGNETIC)) {
                if (player.tickCount % 60 == 0 && !player.level().isClientSide()) {
                    applyElectromagneticField(player);
                }
            }

            // === STORMFRONT YILDIRIM COOLDOWN SAYACI ===
            if (cap.hasPower(SuperPower.LIGHTNING_CONTROL) && !player.level().isClientSide()) {
                if (cap.getLightningCooldownTicks() > 0) {
                    cap.setLightningCooldownTicks(cap.getLightningCooldownTicks() - 1);
                }
            }

            // === NÜKLEER ŞARJ SİSTEMİ (Soldier Boy) ===
            if (cap.hasPower(SuperPower.NUCLEAR_BLAST) && !player.level().isClientSide()) {
                // Cooldown sayacı azalt
                if (cap.getNuclearCooldownTicks() > 0) {
                    cap.setNuclearCooldownTicks(cap.getNuclearCooldownTicks() - 1);
                    // Her 20 saniyede bir bildirim (ilk 3 dakika)
                    int cd = cap.getNuclearCooldownTicks();
                    if (cd == 9000 || cd == 6000 || cd == 3000 || cd == 1200 || cd == 600 || cd == 200 || cd == 60) {
                        player.sendSystemMessage(net.minecraft.network.chat.Component.literal(
                            "§e☢ Nükleer güç: " + (cd / 20) + " saniye sonra hazır."
                        ));
                    }
                    // Patlama kurbanı ise: cooldown bitti → güçler geri gelsin
                    if (cd == 0 && !cap.isPowerEnabled()) {
                        cap.setPowerEnabled(true);
                        player.sendSystemMessage(net.minecraft.network.chat.Component.literal(
                            "§a✦ Güçlerin geri döndü!"
                        ));
                    }
                }

                // Şarj sayacı artır — 1000 tick = 50 saniye
                if (cap.isNuclearCharging()) {
                    int charge = cap.getNuclearChargeTicks() + 1;
                    cap.setNuclearChargeTicks(charge);
                    // Her 200 tick'te bir ilerleme mesajı
                    if (charge % 200 == 0) {
                        player.sendSystemMessage(net.minecraft.network.chat.Component.literal(
                            "§6☢ Şarj: %" + (charge / 10) + " (" + (charge / 20) + "sn)"
                        ));
                    }
                    if (charge >= 1000) {
                        // 50 saniye doldu → patlat!
                        cap.setNuclearCharging(false);
                        cap.setNuclearChargeTicks(0);
                        cap.setNuclearCooldownTicks(12000); // 10 dakika cooldown
                        if (player instanceof net.minecraft.server.level.ServerPlayer sp) {
                            performNuclearBlastServer(sp);
                        }
                    }
                }
            }

            // === HUD SENKRONIZASYONU — her 20 tick'te client'a gönder ===
            if (!player.level().isClientSide() && player.tickCount % 20 == 0) {
                if (player instanceof net.minecraft.server.level.ServerPlayer sp) {
                    PacketHandler.CHANNEL.send(
                        PacketDistributor.PLAYER.with(() -> sp),
                        new SyncPowersPacket(cap.serializeNBT())
                    );
                }
            }

            // === LAZER GÖZ SÜREKLİ ATEŞ + YORGUNLUK ===
            // Yorgunluk sayacı: 0 ise lazer kullanılabilir.
            // Lazer açıkken her tick +1 birikiyor, 100 tick (5sn)'e ulaşınca zorla kapanır.
            // Kapalıyken her tick -2 azalıyor (2.5sn'de toparlanır, tam 60 tick mola gerekir).
            if ((cap.hasPower(SuperPower.LASER_EYES) || cap.hasPower(SuperPower.V24_LASER))
                    && !player.level().isClientSide()) {

                int fatigue = cap.getLaserFatigueTicks();

                if (cap.isLaserActive()) {
                    // Her tick hasar ver
                    if (player instanceof net.minecraft.server.level.ServerPlayer sp) {
                        fireLaserBeamContinuous(sp);
                    }
                    // Yorgunluk biriktir
                    fatigue++;
                    cap.setLaserFatigueTicks(fatigue);
                    if (fatigue >= 100) {
                        // 5 saniye doldu → zorla kapat, 60 tick (3sn) mola
                        cap.setLaserActive(false);
                        cap.setLaserFatigueTicks(60);
                        player.sendSystemMessage(net.minecraft.network.chat.Component.literal(
                            "§7🔴 Lazer gözler dinleniyor... (3 saniye)"
                        ));
                    }
                } else {
                    // Lazer kapalı → yorgunluk azal (toparlan)
                    if (fatigue > 0) {
                        cap.setLaserFatigueTicks(Math.max(0, fatigue - 2));
                    }
                }
            }

        });
    }

    // ===================== ÖLÜMSÜZE YAKIN DAYANIKLILIK =====================
    private void applyNearImmortality(Player player, SuperPowerCapability cap) {
        int amp = cap.getPowerAmplifier(); // 0=normal, 1=güçlenmiş(2.doz), 2=max(3.doz)

        // Direnç: her tick yenile (40 tick = 2sn, görünmez)
        player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 40, 4 + amp, false, false));
        player.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 40, 0, false, false));

        // Health Boost: sadece efekt yoksa veya süresi 100 tick'in altına düştüyse ekle
        // (Her tick eklersek Minecraft canı sıfırlıyor — bu kendi kendine hasar hatasının sebebi)
        int healthBoostLevel = 9 + amp * 5; // amp=0:+20can, amp=1:+30can, amp=2:+40can
        MobEffectInstance existing = player.getEffect(MobEffects.HEALTH_BOOST);
        if (existing == null || existing.getDuration() < 100 || existing.getAmplifier() < healthBoostLevel) {
            player.addEffect(new MobEffectInstance(MobEffects.HEALTH_BOOST, 1200, healthBoostLevel, false, false));
        }

        // Can dolumu: her tick aktif iyileşme (Health Boost eklendikten sonra maxHealth artar)
        float maxHp = player.getMaxHealth();
        if (player.getHealth() < maxHp) {
            float healAmount = 0.5f + amp * 0.25f; // amp=0: 0.5/tick, amp=1: 0.75, amp=2: 1.0
            player.setHealth(Math.min(player.getHealth() + healAmount, maxHp));
        }
    }

    // ===================== SÜPER GÜÇ =====================
    private void applyStrength(Player player, SuperPowerCapability cap) {
        int amp = cap.getPowerAmplifier(); // 0=normal, 1=güçlenmiş, 2=max
        // Hasar: amp=0 → Güç 5, amp=1 → Güç 6, amp=2 → Güç 7
        player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 40, 4 + amp, false, false));
    }

    // ===================== UÇMA =====================
    private void applyFlight(Player player) {
        player.setNoGravity(true);
        player.resetFallDistance();
        player.getAbilities().mayfly = true;
        player.getAbilities().flying = true;
        player.onUpdateAbilities();
    }

    // ===================== SÜRAT + EZME =====================
    private void applySpeedAndDamage(Player player, SuperPowerCapability cap) {
        player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 40, 8, false, false)); // Hız 9

        // Hareket ediyorsa ezme aktif (yavaş yürüme dahil)
        if (player.getDeltaMovement().horizontalDistance() > 0.05) {
            AABB hitBox = player.getBoundingBox().inflate(0.3);
            List<LivingEntity> nearby = player.level().getEntitiesOfClass(
                LivingEntity.class, hitBox,
                e -> e != player && !(e instanceof Player p && p.isCreative())
            );

            for (LivingEntity entity : nearby) {
                if (!entity.isDeadOrDying()) {
                    // A-Train — çok yüksek hasar (anında öldürmez, survival şansı tanır)
                    entity.hurt(player.level().damageSources().playerAttack(player), 80.0f);

                    // Kırmızı kan partikülleri (server → client gönder)
                    if (player.level() instanceof net.minecraft.server.level.ServerLevel serverLevel) {
                        serverLevel.sendParticles(
                            net.minecraft.core.particles.ParticleTypes.DAMAGE_INDICATOR,
                            entity.getX(), entity.getY() + 0.5, entity.getZ(),
                            20,   // adet
                            0.3, 0.5, 0.3,  // spread
                            0.1   // hız
                        );
                        serverLevel.sendParticles(
                            net.minecraft.core.particles.ParticleTypes.CRIT,
                            entity.getX(), entity.getY() + 0.5, entity.getZ(),
                            15,
                            0.4, 0.4, 0.4,
                            0.2
                        );
                    }
                }
            }
        }
    }

    // ===================== ELEKTROMANYETİK ALAN =====================
    private void applyElectromagneticField(Player player) {
        if (!(player.level() instanceof ServerLevel serverLevel)) return;
        AABB range = player.getBoundingBox().inflate(4.0);
        List<LivingEntity> nearby = player.level().getEntitiesOfClass(
            LivingEntity.class, range,
            e -> e != player && !(e instanceof Player) &&
                 e instanceof net.minecraft.world.entity.monster.Monster
        );
        for (LivingEntity entity : nearby) {
            entity.hurt(player.level().damageSources().lightningBolt(), 4.0f);
        }
    }

    // ===================== HASAR AZALTMA (ÖLÜMSÜZLÜK) =====================
    @SubscribeEvent
    public void onLivingDamage(LivingDamageEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;

        SuperPowerCapability.get(player).ifPresent(cap -> {
            if (!cap.isPowerEnabled()) return;

            if (cap.hasPower(SuperPower.NEAR_IMMORTALITY)) {
                net.minecraft.world.damagesource.DamageSource src = event.getSource();

                // Çevresel hasarları (düşme, açlık, boğulma, void) tamamen engelle
                if (src == player.level().damageSources().fall()
                    || src == player.level().damageSources().starve()
                    || src == player.level().damageSources().drown()
                    || src == player.level().damageSources().outOfWorld()
                    || src.getMsgId().equals("fall")
                    || src.getMsgId().equals("starve")
                    || src.getMsgId().equals("drown")) {
                    event.setCanceled(true);
                    return;
                }

                // Kendi kendine hasar (magic geri yansıma vb.) → iptal et
                Entity sourceEntity = src.getEntity();
                if (sourceEntity == null || sourceEntity == player) {
                    event.setCanceled(true);
                    return;
                }

                // Gerçek hasar: %95 azalt, minimumu 0 yap (0.1 bile olsa can azalıyor)
                float original = event.getAmount();
                float reduced = original * 0.05f;
                if (reduced < 0.5f) {
                    // Çok küçük hasar → tamamen iptal (kalp titrememesi için)
                    event.setCanceled(true);
                    return;
                }
                event.setAmount(reduced);

                // Saldıran varlığa geri hasar ver (Stormfront kalkanı ile)
                if (cap.hasPower(SuperPower.STORMFRONT_SHIELD)) {
                    if (sourceEntity instanceof LivingEntity attacker && attacker != player) {
                        attacker.hurt(player.level().damageSources().magic(), original * 0.5f);
                    }
                }
            }
        });
    }

    // ===================== NÜKLEER PATLAMA (SERVER SIDE) =====================
    /**
     * Soldier Boy nükleer patlaması:
     * - Oyuncu hasar almaz
     * - Oyuncu fırlamaz (push yok)
     * - 15 blok yarıçapında düşmanlara 500 hasar
     * - Etkilenen süper güçlü oyuncular güçlerini kaybeder veya zayıflar
     * - 10 dakika cooldown
     */
    private static void performNuclearBlastServer(net.minecraft.server.level.ServerPlayer player) {
        if (!(player.level() instanceof ServerLevel serverLevel)) return;

        net.minecraft.world.phys.Vec3 pos = player.position();

        // Patlama görsel efekti (blok hasarı yok)
        serverLevel.explode(null, pos.x, pos.y + 0.5, pos.z,
            7.0f, false, net.minecraft.world.level.Level.ExplosionInteraction.NONE);

        // 15 blok yarıçapındaki tüm canlılar (oyuncu hariç)
        net.minecraft.world.phys.AABB blastZone = player.getBoundingBox().inflate(15.0);
        List<LivingEntity> victims = player.level().getEntitiesOfClass(
            LivingEntity.class, blastZone, e -> e != player
        );

        for (LivingEntity entity : victims) {
            entity.hurt(player.level().damageSources().explosion(null), 500.0f);

            // Eğer kurban oyuncu ve süper güçlüyse → güçleri azalt/sıfırla
            if (entity instanceof Player victimPlayer) {
                SuperPowerCapability.get(victimPlayer).ifPresent(victimCap -> {
                    if (victimCap.isPowerEnabled() && !victimCap.getActivePowers().isEmpty()) {
                        // Süper güçleri 5 dakika boyunca devre dışı bırak
                        victimCap.setPowerEnabled(false);
                        // Not: Bunu geri açmak için basit bir zamanlayıcı eklemek gerekir.
                        // Şimdilik 6000 tick (5dk) sonra otomatik açılacak şekilde cooldown ekliyoruz.
                        // Bunu PlayerEventHandler'da kontrol edeceğiz.
                        victimCap.setNuclearCooldownTicks(6000); // kurban için güç sıfırlama süresi olarak kullanıyoruz
                        if (victimPlayer instanceof net.minecraft.server.level.ServerPlayer sp) {
                            sp.sendSystemMessage(net.minecraft.network.chat.Component.literal(
                                "§c§l☢ Nükleer patlamadan etkilendin! Güçlerin 5 dakika boyunca zayıfladı!"
                            ));
                        }
                    }
                });
            }
        }

        // Oyuncunun kendisi HARİÇ - hasar yok, fırlama yok
        player.sendSystemMessage(net.minecraft.network.chat.Component.literal("§c§l☢ NÜKLEER PATLAMA! ☢")
            .append(net.minecraft.network.chat.Component.literal(" §7(15 blok yarıçap - sen hasar almadın, 10dk cooldown)")));

        // Client görsel
        PacketHandler.CHANNEL.send(
            net.minecraftforge.network.PacketDistributor.NEAR.with(() -> new net.minecraftforge.network.PacketDistributor.TargetPoint(
                pos.x, pos.y, pos.z, 64.0, player.level().dimension()
            )),
            new com.compoundv.mod.network.NuclearBlastPacket(pos.x, pos.y, pos.z)
        );
    }

    // ===================== LAZER SÜREKLİ ATEŞ =====================
    /**
     * Her tick çağrılır — imleç nereye bakıyorsa oraya lazer.
     * Hasar: 4.0 (silah gibi değil, yakma etkisi)
     */
    private static void fireLaserBeamContinuous(net.minecraft.server.level.ServerPlayer player) {
        net.minecraft.world.phys.Vec3 look = player.getLookAngle();
        net.minecraft.world.phys.Vec3 start = player.getEyePosition();

        for (double dist = 1.0; dist <= 60.0; dist += 0.5) {
            net.minecraft.world.phys.Vec3 point = start.add(look.scale(dist));
            net.minecraft.world.phys.AABB hitBox = new net.minecraft.world.phys.AABB(
                point.x - 0.3, point.y - 0.3, point.z - 0.3,
                point.x + 0.3, point.y + 0.3, point.z + 0.3
            );
            List<LivingEntity> hit = player.level().getEntitiesOfClass(
                LivingEntity.class, hitBox, e -> e != player
            );
            if (!hit.isEmpty()) {
                for (LivingEntity entity : hit) {
                    // Her tick 2.0 hasar (sürekli yakma, saniyede 40 hasar)
                    entity.hurt(player.level().damageSources().playerAttack(player), 2.0f);
                    entity.setSecondsOnFire(3);
                }
                break; // İlk çarpılan varlıkta dur
            }
        }
    }

    // ===================== PLAYER KOPYA (RESPAWN) =====================
    @SubscribeEvent
    public void onPlayerClone(PlayerEvent.Clone event) {
        if (!event.isWasDeath()) return;
        Player original = event.getOriginal();
        Player newPlayer = event.getEntity();

        original.reviveCaps();
        SuperPowerCapability.get(original).ifPresent(oldCap -> {
            SuperPowerCapability.get(newPlayer).ifPresent(newCap -> {
                newCap.deserializeNBT(oldCap.serializeNBT());
            });
        });
        original.invalidateCaps();
    }
}
