# ⚡ Compound V Mod — v1.3 (The Boys)

Minecraft Forge 1.20.1 için The Boys evreninden ilhamlanan süper güç modu.

---

## 🎮 Tuş Atamaları

| Tuş | Güç | Açıklama |
|-----|-----|----------|
| **Z** | ☢ Nükleer Patlama (Soldier Boy) | Basınca 50 saniyelik şarj başlar. Şarj dolunca otomatik patlar. 10 dk cooldown. |
| **G** | ✈ Uçma Toggle | Uçmayı aç/kapat |
| **H** | 🔴 Lazer Göz Toggle | Lazeri aç/kapat. Açıkken sürekli imlecin baktığı yeri yakar. Max 5sn, sonra 3sn mola. |
| **N** | ⚡ Yıldırım (Stormfront) | Etrafındaki düşmanlara yıldırım çarptır |

---

## 🧬 Serum Sistemi

### V1 Serumu
- **1. Doz:** Zorunlu güçler + rastgele güçler atanır
  - %20 şans: Lazer Göz, Uçma, **Yıldırım Kontrolü (Stormfront)**
  - %40 şans: Sürat, Yenilenme, EM Alan, Stormfront Kalkanı
  - %20 şans: Soldier Boy paketi (Boyut + Nükleer Patlama)
- **2. Doz:** %80 güç yükselmesi, %20 yeni güç
- **3. Doz:** Aynı — maksimum 3 doz!

---

## ⚡ Güç Detayları

### ☢ Nükleer Patlama (Soldier Boy — Z Tuşu)
- Z'ye basınca **50 saniyelik şarj** başlar
- Şarj ekranına ilerleme mesajları gelir (%10, %20...)
- 50 saniye dolunca **imlecin baktığı konuma** otomatik patlar
- 15 blok yarıçapındaki tüm varlıklara 500 hasar
- **Oyuncu hasar almaz, fırlamaz**
- Etkilenen süper güçlü oyuncuların güçleri **5 dakika devre dışı** kalır
- Patlama sonrası **10 dakika cooldown**

### 🔴 Lazer Göz (H Tuşu)
- H'ye basınca lazer **açılır** — kapatana kadar sürekli ateş eder
- İmleç nereye bakıyorsa orası yanar
- **Max 5 saniye** sürekli kullanım, ardından **3 saniye zorunlu mola**
- Mola bitmeden H'ye bassanız "dinleniyor" mesajı alırsınız

### ⚡ Yıldırım Kontrolü — Stormfront (N Tuşu)
- 12 blok yarıçapındaki tüm düşmanlara yıldırım çarptır
- **Stormfront Kalkanı** ile birlikte gelir (hasar yansıtır)
- V1 ile %20 şansla kazanılır

### ✈ Uçma (G Tuşu)
- Toggle — G'ye basarak aç/kapat

---

## 🛡 Pasif Güçler

| Güç | Efekt |
|-----|-------|
| Ölümsüze Yakın Dayanıklılık | Hasar %95 azalır, hızlı iyileşme, yüksek can |
| Süper Güç | Güçlü yumruk hasarı |
| Stormfront Kalkanı | Sürekli hasar direnci, saldırganları geri hasar |
| Elektromanyetik Alan | Etraftaki canavarları otomatik elektrikler |
| Yenilenme | Her saniye 1 can iyileşir |
| Sürat (A-Train) | Üstünden geçtiğin her şeyi anında öldürür |

---

## 🔧 Düzeltmeler (v1.3)

- ✅ Stormfront yıldırımı artık V1 ile kazanılabilir (%20 şans, RARE tier)
- ✅ Soldier Boy patlaması artık anlık değil — 50 sn şarj sistemi
- ✅ Soldier Boy patlama sırasında oyuncu hasar almaz ve fırlamaz
- ✅ Lazer sürekli ateş sistemi — açınca imlece bakan her şeyi yakar
- ✅ Lazer yorgunluk sistemi — 5sn kullanım → 3sn zorunlu mola
- ✅ Patlama etkilenen süper güçlü oyuncular 5dk güç kaybeder

