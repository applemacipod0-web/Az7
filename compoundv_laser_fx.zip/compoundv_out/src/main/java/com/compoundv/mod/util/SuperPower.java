package com.compoundv.mod.util;

/**
 * Tüm süper güçlerin tanımları - The Boys evreninden
 */
public enum SuperPower {

    // === ZORUNLU (V1'de her zaman var) ===
    NEAR_IMMORTALITY("near_immortality", "Ölümsüze Yakın Dayanıklılık", PowerTier.MANDATORY),
    SUPER_STRENGTH("super_strength", "Süper Güç", PowerTier.MANDATORY),

    // === RASTGELE GÜÇLER ===
    LASER_EYES("laser_eyes", "Lazer Gözler", PowerTier.RARE),
    FLIGHT("flight", "Uçma", PowerTier.RARE),
    SUPER_SPEED("super_speed", "Sürat", PowerTier.UNCOMMON),
    LIGHTNING_CONTROL("lightning_control", "Yıldırım Kontrolü (Stormfront)", PowerTier.RARE),
    ELECTROMAGNETIC("electromagnetic", "Elektromanyetik Alan", PowerTier.UNCOMMON),
    REGENERATION("regeneration", "Hızlı İyileşme", PowerTier.UNCOMMON),
    SOLDIER_SIZE("soldier_size", "Asker Boyutu (Soldier Boy)", PowerTier.UNCOMMON),
    NUCLEAR_BLAST("nuclear_blast", "Nükleer Patlama (Z Tuşu)", PowerTier.UNCOMMON), // Sadece Soldier Boy paketiyle gelir
    STORMFRONT_SHIELD("stormfront_shield", "Stormfront Kalkanı", PowerTier.RARE),

    // === COMPOUND V ÖZEL GÜÇLERİ ===
    UNDERWATER_TELEPATHY("underwater_telepathy", "Su Altı Telepatisi (The Deep)", PowerTier.COMPOUND_V),
    LIGHT_MANIPULATION("light_manipulation", "Işık Manipülasyonu (Starlight)", PowerTier.COMPOUND_V),
    FIRE_CONTROL("fire_control", "Ateş Kontrolü (Lamplighter)", PowerTier.COMPOUND_V),
    BLOOD_MANIPULATION("blood_manipulation", "Kan Manipülasyonu (Neuman)", PowerTier.COMPOUND_V),
    SELF_EXPLOSION("self_explosion", "Kendini Patlatma (Naqib)", PowerTier.COMPOUND_V),
    MIND_PRISON("mind_prison", "Zihin Hapsatme (Mindstorm)", PowerTier.COMPOUND_V),
    SELF_CLONE("self_clone", "Kendini Kopyalama (Splinter)", PowerTier.COMPOUND_V),
    HEAT_VISION("heat_vision", "Isı Görüşü (Homelander)", PowerTier.COMPOUND_V),

    // === V24 ÖZEL ===
    V24_LASER("v24_laser", "V24 Lazer Göz", PowerTier.V24),
    V24_DURABILITY("v24_durability", "V24 Dayanıklılık", PowerTier.V24),
    V24_STRENGTH("v24_strength", "V24 Süper Güç", PowerTier.V24);

    public final String id;
    public final String displayName;
    public final PowerTier tier;

    SuperPower(String id, String displayName, PowerTier tier) {
        this.id = id;
        this.displayName = displayName;
        this.tier = tier;
    }

    public enum PowerTier {
        MANDATORY,    // Her zaman verilir
        UNCOMMON,     // %40 şans
        RARE,         // %20 şans
        COMPOUND_V,   // Compound V'ye özel
        V24           // V24'e özel
    }
}
