package com.compoundv.mod.item;

import com.compoundv.mod.CompoundVMod;
import com.compoundv.mod.block.ModBlocks;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {

    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, CompoundVMod.MOD_ID);

    public static final DeferredRegister<CreativeModeTab> CREATIVE_TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, CompoundVMod.MOD_ID);

    // ===== SERUMLAR =====

    /**
     * V1 Serumu - Rastgele güçler, ölümsüze yakın, süper güçlü
     * Özel serum yapıcıda üretilir
     */
    public static final RegistryObject<Item> SERUM_V1 =
            ITEMS.register("serum_v1", SerumV1Item::new);

    /**
     * Ham Compound V - Serum yapıcı için hammadde
     */
    public static final RegistryObject<Item> RAW_COMPOUND_V =
            ITEMS.register("raw_compound_v", () -> new Item(new Item.Properties().stacksTo(16)));

    /**
     * Stabilizör - Serum kararlılığı için gerekli
     */
    public static final RegistryObject<Item> STABILIZER =
            ITEMS.register("stabilizer", () -> new Item(new Item.Properties().stacksTo(16)));

    /**
     * V Temizleyici - Tüm güçleri sıfırlar, V1 tekrar içilebilir
     */
    public static final RegistryObject<Item> SERUM_CLEANSER =
            ITEMS.register("serum_cleanser", SerumCleanserItem::new);

    // ===== CREATIVE TABS =====

    /**
     * 1. Sekme: Serumlar ve Malzemeler
     */
    public static final RegistryObject<CreativeModeTab> COMPOUND_V_TAB =
            CREATIVE_TABS.register("compound_v_tab", () ->
                    CreativeModeTab.builder()
                            .title(Component.literal("§c§lCompound V - Serumlar"))
                            .icon(() -> new ItemStack(SERUM_V1.get()))
                            .displayItems((params, output) -> {
                                // Serumlar
                                output.accept(SERUM_V1.get());
                                // Hammaddeler
                                output.accept(RAW_COMPOUND_V.get());
                                output.accept(STABILIZER.get());
                                output.accept(SERUM_CLEANSER.get());
                            })
                            .build()
            );

    /**
     * 2. Sekme: Makineler ve Bloklar
     */
    public static final RegistryObject<CreativeModeTab> COMPOUND_V_MACHINES_TAB =
            CREATIVE_TABS.register("compound_v_machines_tab", () ->
                    CreativeModeTab.builder()
                            .title(Component.literal("§6§lCompound V - Makineler"))
                            .icon(() -> new ItemStack(ModBlocks.SERUM_MAKER.get().asItem()))
                            .displayItems((params, output) -> {
                                // Bloklar / Makineler
                                output.accept(ModBlocks.SERUM_MAKER.get());
                            })
                            .build()
            );
}
