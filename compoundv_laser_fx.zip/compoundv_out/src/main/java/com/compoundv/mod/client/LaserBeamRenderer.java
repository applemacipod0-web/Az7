package com.compoundv.mod.client;

import com.compoundv.mod.capability.SuperPowerCapability;
import com.compoundv.mod.util.SuperPower;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import org.joml.Matrix4f;

/**
 * Lazer gözler için gerçek zamanlı render-line görsel efekti.
 *
 * Katmanlar (içten dışa):
 *   1. Beyaz çekirdek  — genişlik 0.015  (saf beyaz, tam opak)
 *   2. Kırmızı iç halo — genişlik 0.035  (kırmızı, %85 opak)
 *   3. Kırmızı dış halo — genişlik 0.07  (kırmızı, %30 opak, glow)
 *
 * Render tekniği:
 *   - GL_LINES yerine ince quad-strip (4 köşeli çizgi) çiziyoruz.
 *     Bu sayede genişlik kontrol edilebilir ve her açıdan görünür.
 *   - Her katman ayrı draw call ile çizilir; depth write kapatılır,
 *     additive blend kullanılır → doğal glow efekti.
 *   - Işın kaynağı: her iki gözden ayrı (dual beam).
 *   - Beam uzunluğu: 60 blok (server ile aynı).
 */
@OnlyIn(Dist.CLIENT)
public class LaserBeamRenderer {

    // ── Renk sabitleri ──────────────────────────────────────────────
    private static final float CORE_R   = 1.0f, CORE_G   = 1.0f, CORE_B   = 1.0f; // Beyaz çekirdek
    private static final float INNER_R  = 1.0f, INNER_G  = 0.05f, INNER_B = 0.05f; // Kırmızı iç
    private static final float OUTER_R  = 1.0f, OUTER_G  = 0.0f,  OUTER_B = 0.0f;  // Kırmızı dış

    private static final float CORE_ALPHA  = 1.00f;
    private static final float INNER_ALPHA = 0.85f;
    private static final float OUTER_ALPHA = 0.30f;

    // ── Beam genişlikleri (yarı genişlik — her iki yana) ────────────
    private static final float HALF_W_CORE  = 0.013f;
    private static final float HALF_W_INNER = 0.030f;
    private static final float HALF_W_OUTER = 0.065f;

    // ── Beam uzunluğu ────────────────────────────────────────────────
    private static final double BEAM_LENGTH = 60.0;

    // ── Çift göz ofseti (L/R) ────────────────────────────────────────
    // Minecraft'ta her iki lazer aynı noktadan çıkmak yerine
    // gözler arası ~0.08 blok sağa/sola offset ile çizilir.
    private static final float EYE_OFFSET = 0.06f;

    @SubscribeEvent
    public void onRenderLevel(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_TRANSLUCENT_BLOCKS) return;

        Minecraft mc = Minecraft.getInstance();
        Player player = mc.player;
        if (player == null) return;

        // Sadece lazer aktifse çiz
        SuperPowerCapability.get(player).ifPresent(cap -> {
            if (!cap.isLaserActive()) return;
            boolean hasLaser = cap.hasPower(SuperPower.LASER_EYES)
                            || cap.hasPower(SuperPower.V24_LASER);
            if (!hasLaser) return;

            Camera camera = mc.gameRenderer.getMainCamera();
            Vec3 camPos = camera.getPosition();

            // Partial tick ile smooth pozisyon
            double pt = event.getPartialTick();

            // Oyuncunun göz pozisyonu (camera-space'e göre rölatif)
            Vec3 eyePos = player.getEyePosition(pt);
            Vec3 look    = player.getLookAngle();

            // Camera'ya göre rölatif başlangıç (render koordinatları)
            double rx = eyePos.x - camPos.x;
            double ry = eyePos.y - camPos.y;
            double rz = eyePos.z - camPos.z;

            // Işın uç noktası
            double ex = rx + look.x * BEAM_LENGTH;
            double ey = ry + look.y * BEAM_LENGTH;
            double ez = rz + look.z * BEAM_LENGTH;

            // Camera'nın sağ vektörü (quad orientation için)
            Vec3 camRight = getRightVector(camera);

            // Projection+View matrisi
            Matrix4f poseMatrix = event.getPoseStack().last().pose();

            // Sol ve sağ göz offset'leri
            drawDualBeam(poseMatrix, camRight,
                    rx, ry, rz, ex, ey, ez,
                    look);
        });
    }

    // ── İkili lazer ışını (sol göz + sağ göz) ───────────────────────
    private void drawDualBeam(Matrix4f pose, Vec3 right,
                              double ox, double oy, double oz,
                              double ex, double ey, double ez,
                              Vec3 look) {

        // Sol göz
        drawBeamLayers(pose, right,
                ox - right.x * EYE_OFFSET,
                oy - right.y * EYE_OFFSET,
                oz - right.z * EYE_OFFSET,
                ex - right.x * EYE_OFFSET,
                ey - right.y * EYE_OFFSET,
                ez - right.z * EYE_OFFSET,
                look);

        // Sağ göz
        drawBeamLayers(pose, right,
                ox + right.x * EYE_OFFSET,
                oy + right.y * EYE_OFFSET,
                oz + right.z * EYE_OFFSET,
                ex + right.x * EYE_OFFSET,
                ey + right.y * EYE_OFFSET,
                ez + right.z * EYE_OFFSET,
                look);
    }

    // ── Bir ışın için 3 katmanı sırayla çiz ─────────────────────────
    private void drawBeamLayers(Matrix4f pose, Vec3 right,
                                double ox, double oy, double oz,
                                double ex, double ey, double ez,
                                Vec3 look) {
        // Dış halo (önce — additive blend sırası önemli)
        drawBeamQuad(pose, right, ox, oy, oz, ex, ey, ez,
                HALF_W_OUTER, OUTER_R, OUTER_G, OUTER_B, OUTER_ALPHA);

        // İç halo
        drawBeamQuad(pose, right, ox, oy, oz, ex, ey, ez,
                HALF_W_INNER, INNER_R, INNER_G, INNER_B, INNER_ALPHA);

        // Beyaz çekirdek (en üstte)
        drawBeamQuad(pose, right, ox, oy, oz, ex, ey, ez,
                HALF_W_CORE, CORE_R, CORE_G, CORE_B, CORE_ALPHA);
    }

    /**
     * Tek bir beam katmanını quad olarak çizer.
     *
     * Quad düzeni (camera-facing billboard):
     *   p0 ─── p1   (başlangıç, sol-sağ)
     *   |         |
     *   p3 ─── p2   (bitiş,     sol-sağ)
     *
     * "right" vektörü her iki taraf için yönü belirler.
     */
    private void drawBeamQuad(Matrix4f pose, Vec3 right,
                              double ox, double oy, double oz,
                              double ex, double ey, double ez,
                              float halfW,
                              float r, float g, float b, float a) {

        // RenderSystem durumu
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();   // SRC_ALPHA + ONE_MINUS_SRC_ALPHA (normal)
        RenderSystem.disableDepthTest();   // Bloklarla örtüşmesin, her zaman görünsün
        RenderSystem.depthMask(false);
        RenderSystem.disableCull();
        RenderSystem.setShader(GameRenderer::getPositionColorShader);

        Tesselator tess = Tesselator.getInstance();
        BufferBuilder buf = tess.getBuilder();
        buf.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_COLOR);

        float rx = (float) right.x * halfW;
        float ry = (float) right.y * halfW;
        float rz = (float) right.z * halfW;

        float sx = (float) ox, sy = (float) oy, sz = (float) oz;
        float dx = (float) ex, dy = (float) ey, dz = (float) ez;

        int ri = (int)(r * 255), gi = (int)(g * 255), bi = (int)(b * 255), ai = (int)(a * 255);

        // Quad köşeleri
        buf.vertex(pose, sx - rx, sy - ry, sz - rz).color(ri, gi, bi, ai).endVertex();
        buf.vertex(pose, sx + rx, sy + ry, sz + rz).color(ri, gi, bi, ai).endVertex();
        buf.vertex(pose, dx + rx, dy + ry, dz + rz).color(ri, gi, bi, ai).endVertex();
        buf.vertex(pose, dx - rx, dy - ry, dz - rz).color(ri, gi, bi, ai).endVertex();

        tess.end();

        // RenderSystem sıfırla
        RenderSystem.enableDepthTest();
        RenderSystem.depthMask(true);
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }

    // ── Kamera sağ vektörü ───────────────────────────────────────────
    private Vec3 getRightVector(Camera camera) {
        // Camera yaw/pitch'ten sağ vektörünü hesapla
        float yawRad   = (float) Math.toRadians(camera.getYRot());
        float pitchRad = (float) Math.toRadians(camera.getXRot());

        // Sağ vektör = yaw'a 90° dik
        double rx = -Math.cos(yawRad);
        double ry = 0;
        double rz = -Math.sin(yawRad);

        // Uzunluğu normalize et
        double len = Math.sqrt(rx * rx + ry * ry + rz * rz);
        if (len < 1e-6) return new Vec3(1, 0, 0);
        return new Vec3(rx / len, ry / len, rz / len);
    }
}
