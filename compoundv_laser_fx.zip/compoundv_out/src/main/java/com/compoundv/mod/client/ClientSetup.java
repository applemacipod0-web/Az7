package com.compoundv.mod.client;

import com.compoundv.mod.client.screen.SerumMakerScreen;
import com.compoundv.mod.menu.ModMenuTypes;
import net.minecraft.client.gui.screens.MenuScreens;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;

@Mod.EventBusSubscriber(modid = "compoundv", bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientSetup {

    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent event) {
        event.enqueueWork(() -> {
            MenuScreens.register(ModMenuTypes.SERUM_MAKER.get(), SerumMakerScreen::new);
            // HUD Overlay'i kaydet
            MinecraftForge.EVENT_BUS.register(new PowerHudOverlay());
            // Lazer ışını render'ını kaydet
            MinecraftForge.EVENT_BUS.register(new LaserBeamRenderer());
        });
    }
}
