package com.compoundv.mod.blockentity;

import com.compoundv.mod.CompoundVMod;
import com.compoundv.mod.block.ModBlocks;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModBlockEntities {

    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, CompoundVMod.MOD_ID);

    public static final RegistryObject<BlockEntityType<SerumMakerBlockEntity>> SERUM_MAKER =
            BLOCK_ENTITIES.register("serum_maker", () ->
                    BlockEntityType.Builder.of(SerumMakerBlockEntity::new,
                            ModBlocks.SERUM_MAKER.get()).build(null));
}
