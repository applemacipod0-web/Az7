package com.compoundv.mod.blockentity;

import com.compoundv.mod.block.SerumMakerBlock;
import com.compoundv.mod.item.ModItems;
import com.compoundv.mod.menu.SerumMakerMenu;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.Containers;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.ForgeCapabilities;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.items.ItemStackHandler;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class SerumMakerBlockEntity extends BlockEntity implements MenuProvider {

    // 4 slot: 3 girdi + 1 çıktı
    private final ItemStackHandler itemHandler = new ItemStackHandler(4) {
        @Override
        protected void onContentsChanged(int slot) {
            setChanged();
        }

        @Override
        public boolean isItemValid(int slot, @NotNull ItemStack stack) {
            if (slot == 3) return false; // çıktı slotu
            return true;
        }
    };

    private LazyOptional<IItemHandler> lazyItemHandler = LazyOptional.empty();

    // Progress verisi (GUI ile senkron)
    private int progress = 0;
    private int maxProgress = 200; // 10 saniye (20 tick/s)

    protected final ContainerData data = new ContainerData() {
        @Override
        public int get(int index) {
            return switch (index) {
                case 0 -> SerumMakerBlockEntity.this.progress;
                case 1 -> SerumMakerBlockEntity.this.maxProgress;
                default -> 0;
            };
        }

        @Override
        public void set(int index, int value) {
            switch (index) {
                case 0 -> SerumMakerBlockEntity.this.progress = value;
                case 1 -> SerumMakerBlockEntity.this.maxProgress = value;
            }
        }

        @Override
        public int getCount() { return 2; }
    };

    public SerumMakerBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.SERUM_MAKER.get(), pos, state);
    }

    @Override
    public Component getDisplayName() {
        return Component.literal("Serum Maker");
    }

    @Override
    public @Nullable AbstractContainerMenu createMenu(int id, Inventory inv, Player player) {
        return new SerumMakerMenu(id, inv, this, this.data);
    }

    @Override
    public @NotNull <T> LazyOptional<T> getCapability(@NotNull Capability<T> cap, @Nullable Direction side) {
        if (cap == ForgeCapabilities.ITEM_HANDLER) return lazyItemHandler.cast();
        return super.getCapability(cap, side);
    }

    @Override
    public void onLoad() {
        super.onLoad();
        lazyItemHandler = LazyOptional.of(() -> itemHandler);
    }

    @Override
    public void invalidateCaps() {
        super.invalidateCaps();
        lazyItemHandler.invalidate();
    }

    // ===================== TICK =====================
    public static void tick(Level level, BlockPos pos, BlockState state, SerumMakerBlockEntity be) {
        if (level.isClientSide()) return;

        if (be.hasValidRecipe()) {
            be.progress++;

            // LIT durumu
            if (!state.getValue(SerumMakerBlock.LIT)) {
                level.setBlock(pos, state.setValue(SerumMakerBlock.LIT, true), 3);
            }

            if (be.progress >= be.maxProgress) {
                be.craftSerum();
                be.progress = 0;
            }
        } else {
            // Malzeme yoksa sıfırla
            if (be.progress > 0) be.progress = 0;
            if (state.getValue(SerumMakerBlock.LIT)) {
                level.setBlock(pos, state.setValue(SerumMakerBlock.LIT, false), 3);
            }
        }

        setChanged(level, pos, state);
    }

    // ===================== RECIPE KONTROLÜ =====================
    private boolean hasValidRecipe() {
        // Girdi slotlarındaki malzemeleri topla (sıra bağımsız)
        int rawCount = 0, stabCount = 0, diamondCount = 0;
        for (int i = 0; i < 3; i++) {
            ItemStack s = itemHandler.getStackInSlot(i);
            if (s.isEmpty()) continue;
            if (s.getItem() == ModItems.RAW_COMPOUND_V.get()) rawCount++;
            else if (s.getItem() == ModItems.STABILIZER.get()) stabCount++;
            else if (s.getItem() == net.minecraft.world.item.Items.DIAMOND) diamondCount++;
        }
        if (rawCount < 1 || stabCount < 1 || diamondCount < 1) return false;

        ItemStack output = itemHandler.getStackInSlot(3);
        return output.isEmpty() ||
                (output.getItem() == ModItems.SERUM_V1.get() && output.getCount() < output.getMaxStackSize());
    }

    private void craftSerum() {
        if (!hasValidRecipe()) return;

        ItemStack result = new ItemStack(ModItems.SERUM_V1.get());
        ItemStack currentOutput = itemHandler.getStackInSlot(3);

        if (currentOutput.isEmpty()) {
            itemHandler.setStackInSlot(3, result);
        } else {
            currentOutput.grow(1);
        }

        // Malzemeleri tüket (sıra bağımsız — ilk bulunanı azalt)
        boolean rawConsumed = false, stabConsumed = false, diamondConsumed = false;
        for (int i = 0; i < 3; i++) {
            ItemStack s = itemHandler.getStackInSlot(i);
            if (!rawConsumed && s.getItem() == ModItems.RAW_COMPOUND_V.get()) {
                s.shrink(1); rawConsumed = true;
            } else if (!stabConsumed && s.getItem() == ModItems.STABILIZER.get()) {
                s.shrink(1); stabConsumed = true;
            } else if (!diamondConsumed && s.getItem() == net.minecraft.world.item.Items.DIAMOND) {
                s.shrink(1); diamondConsumed = true;
            }
        }
    }


    // ===================== NBT =====================
    @Override
    protected void saveAdditional(CompoundTag tag) {
        tag.put("inventory", itemHandler.serializeNBT());
        tag.putInt("progress", progress);
        super.saveAdditional(tag);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        itemHandler.deserializeNBT(tag.getCompound("inventory"));
        progress = tag.getInt("progress");
    }

    // Envanterdeki itemleri düşür (blok kırılınca)
    public void drops() {
        SimpleContainer inv = new SimpleContainer(itemHandler.getSlots());
        for (int i = 0; i < itemHandler.getSlots(); i++) {
            inv.setItem(i, itemHandler.getStackInSlot(i));
        }
        Containers.dropContents(this.level, this.worldPosition, inv);
    }

    public ItemStackHandler getItemHandler() { return itemHandler; }
}
