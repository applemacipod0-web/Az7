package com.compoundv.mod.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@OnlyIn(Dist.CLIENT)
public class ModKeyBindings {

    public static final String CATEGORY = "key.category.compoundv";

    /**
     * Z - Nükleer Patlama (V1 zorunlu güç)
     */
    public static final KeyMapping NUCLEAR_BLAST = new KeyMapping(
            "key.compoundv.nuclear_blast",
            InputConstants.Type.KEYSYM,
            GLFW.GLFW_KEY_Z,
            CATEGORY
    );

    /**
     * G - Uçma Toggle
     */
    public static final KeyMapping TOGGLE_FLIGHT = new KeyMapping(
            "key.compoundv.toggle_flight",
            InputConstants.Type.KEYSYM,
            GLFW.GLFW_KEY_G,
            CATEGORY
    );

    /**
     * H - Lazer Göz Toggle
     */
    public static final KeyMapping TOGGLE_LASER = new KeyMapping(
            "key.compoundv.toggle_laser",
            InputConstants.Type.KEYSYM,
            GLFW.GLFW_KEY_H,
            CATEGORY
    );

    /**
     * N - Yıldırım Kontrolü Toggle (Stormfront)
     */
    public static final KeyMapping TOGGLE_LIGHTNING = new KeyMapping(
            "key.compoundv.toggle_lightning",
            InputConstants.Type.KEYSYM,
            GLFW.GLFW_KEY_N,
            CATEGORY
    );

    @Mod.EventBusSubscriber(value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
    public static class ModBusEvents {
        @SubscribeEvent
        public static void registerKeyMappings(RegisterKeyMappingsEvent event) {
            event.register(NUCLEAR_BLAST);
            event.register(TOGGLE_FLIGHT);
            event.register(TOGGLE_LASER);
            event.register(TOGGLE_LIGHTNING);
        }
    }
}
