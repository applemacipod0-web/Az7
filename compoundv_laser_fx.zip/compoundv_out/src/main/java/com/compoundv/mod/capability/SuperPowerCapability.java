package com.compoundv.mod.capability;

import com.compoundv.mod.CompoundVMod;
import com.compoundv.mod.util.SuperPower;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.common.capabilities.*;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.event.AttachCapabilitiesEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class SuperPowerCapability implements ICapabilitySerializable<CompoundTag> {

    public static final Capability<SuperPowerCapability> CAPABILITY = CapabilityManager.get(new CapabilityToken<>(){});
    public static final ResourceLocation ID = CompoundVMod.rl("superpower");

    private final List<SuperPower> activePowers = new ArrayList<>();
    private boolean powerEnabled = true;
    private boolean isFlying = false;
    private boolean laserActive = false;
    private boolean lightningActive = false;
    private boolean nuclearCharged = false;
    private int nuclearChargeTicks = 0;   // Z basıldığında dolum sayacı (0-1000, 1000=50sn)
    private int nuclearCooldownTicks = 0; // Patlama sonrası bekleme (12000 tick = 10dk)
    private boolean nuclearCharging = false; // Z'ye basılıp basılmadığı
    private int laserFatigueTicks = 0;    // Lazer yorgunluk sayacı
    private int lightningCooldownTicks = 0; // Stormfront yıldırım cooldown (200 tick = 10sn) (lazer zorla kapanır)
    private float sizeMultiplier = 1.0f;
    private int serumType = 0; // 0=none, 1=V1, 2=CompoundV, 3=V24, 4=ModernV
    private int v1DrinkCount = 0; // Kaç kez V1 içildi (max 3)

    private final LazyOptional<SuperPowerCapability> lazyOptional = LazyOptional.of(() -> this);

    // ===================== GÜÇLER =====================

    public void addPower(SuperPower power) {
        if (!activePowers.contains(power)) {
            activePowers.add(power);
        }
    }

    public boolean hasPower(SuperPower power) {
        return activePowers.contains(power);
    }

    public List<SuperPower> getActivePowers() {
        return activePowers;
    }

    public void clearPowers() {
        activePowers.clear();
        sizeMultiplier = 1.0f;
        serumType = 0;
        v1DrinkCount = 0;
    }

    public int getSerumType() { return serumType; }
    public void setSerumType(int type) { this.serumType = type; }

    public int getV1DrinkCount() { return v1DrinkCount; }
    public void setV1DrinkCount(int count) { this.v1DrinkCount = count; }

    public boolean isPowerEnabled() { return powerEnabled; }
    public void setPowerEnabled(boolean enabled) { this.powerEnabled = enabled; }

    public boolean isFlying() { return isFlying; }
    public void setFlying(boolean flying) { this.isFlying = flying; }

    public boolean isLaserActive() { return laserActive; }
    public void setLaserActive(boolean active) { this.laserActive = active; }

    public boolean isLightningActive() { return lightningActive; }
    public void setLightningActive(boolean active) { this.lightningActive = active; }

    public boolean isNuclearCharged() { return nuclearCharged; }
    public void setNuclearCharged(boolean charged) { this.nuclearCharged = charged; }

    public int getNuclearChargeTicks() { return nuclearChargeTicks; }
    public void setNuclearChargeTicks(int t) { this.nuclearChargeTicks = t; }
    public int getNuclearCooldownTicks() { return nuclearCooldownTicks; }
    public void setNuclearCooldownTicks(int t) { this.nuclearCooldownTicks = t; }
    public boolean isNuclearCharging() { return nuclearCharging; }
    public void setNuclearCharging(boolean b) { this.nuclearCharging = b; }
    public int getLaserFatigueTicks() { return laserFatigueTicks; }
    public int getLightningCooldownTicks() { return lightningCooldownTicks; }
    public void setLightningCooldownTicks(int t) { this.lightningCooldownTicks = t; }
    public void setLaserFatigueTicks(int t) { this.laserFatigueTicks = t; }

    public float getSizeMultiplier() { return sizeMultiplier; }
    public void setSizeMultiplier(float multiplier) { this.sizeMultiplier = multiplier; }

    // ===================== V1 SERUM UYGULAMASI =====================

    /**
     * V1 Serumu uygular:
     * - Zorunlu: Ölümsüze yakın dayanıklılık, Süper güç
     * - Rastgele: Diğer güçlerden birkaçı
     * - %30 şansla Soldier Boy paketi: Asker boyutu + Nükleer patlama (Z tuşu)
     */
    /**
     * V1 Serumu içme sistemi:
     * - 1. içiş: Normal güçler atanır
     * - 2. içiş: %80 mevcut güçler güçlenir, %20 yeni güç gelir
     * - 3. içiş: Aynı şekilde %80 güçlenme, %20 yeni güç
     * - 4+. içiş: Engellenir
     */
    public void applyV1Serum(Random random) {
        v1DrinkCount++;
        serumType = 1;

        if (v1DrinkCount == 1) {
            // === 1. İÇİŞ: Temiz başlangıç ===
            activePowers.clear();
            sizeMultiplier = 1.0f;

            addPower(SuperPower.NEAR_IMMORTALITY);
            addPower(SuperPower.SUPER_STRENGTH);

            for (SuperPower power : SuperPower.values()) {
                if (power.tier == SuperPower.PowerTier.RARE) {
                    // Stormfront güçleri rastgele RARE'den gelmesin, paket ile gelsin
                    if (power == SuperPower.LIGHTNING_CONTROL) continue;
                    if (power == SuperPower.STORMFRONT_SHIELD) continue;
                    if (random.nextFloat() < 0.20f) addPower(power);
                } else if (power.tier == SuperPower.PowerTier.UNCOMMON) {
                    if (power == SuperPower.NUCLEAR_BLAST) continue;
                    if (power == SuperPower.SOLDIER_SIZE) continue;
                    if (power == SuperPower.ELECTROMAGNETIC) continue; // Stormfront paketiyle gelir
                    if (random.nextFloat() < 0.40f) addPower(power);
                }
            }

            float specialRoll = random.nextFloat();
            if (specialRoll < 0.20f) {
                // %20: Soldier Boy paketi
                addPower(SuperPower.SOLDIER_SIZE);
                addPower(SuperPower.NUCLEAR_BLAST);
                sizeMultiplier = 1.0f + (random.nextFloat() * 0.5f);
                // Stormfront güçleri Soldier Boy ile gelmiyor
                activePowers.remove(SuperPower.LIGHTNING_CONTROL);
                activePowers.remove(SuperPower.STORMFRONT_SHIELD);
                activePowers.remove(SuperPower.ELECTROMAGNETIC);
            } else if (specialRoll < 0.40f) {
                // %20: Stormfront paketi (Soldier Boy ile çakışmaz)
                addPower(SuperPower.LIGHTNING_CONTROL);
                addPower(SuperPower.STORMFRONT_SHIELD);
                addPower(SuperPower.ELECTROMAGNETIC);
                // Soldier Boy güçleri Stormfront ile gelmiyor
                activePowers.remove(SuperPower.SOLDIER_SIZE);
                activePowers.remove(SuperPower.NUCLEAR_BLAST);
            }

        } else {
            // === 2. ve 3. İÇİŞ: %80 güçlenme, %20 yeni güç ===
            if (random.nextFloat() < 0.80f) {
                // %80: Mevcut güçler güçlenir
                // Boyut çarpanı artar (Soldier Boy varsa)
                if (hasPower(SuperPower.SOLDIER_SIZE)) {
                    sizeMultiplier = Math.min(sizeMultiplier + 0.3f, 2.5f); // max 2.5x
                }
                // Zorunlu güçler zaten var, güçlenme efekti olarak amplifier artacak
                // (PlayerEventHandler bu değeri okuyacak)
                powerAmplifier = Math.min(powerAmplifier + 1, 2); // 0→1→2 (max 3. seviye)
            } else {
                // %20: Yeni rastgele güç ekle (henüz sahip olunmayan birini)
                List<SuperPower> notOwned = new java.util.ArrayList<>();
                for (SuperPower power : SuperPower.values()) {
                    if (!hasPower(power)
                        && power.tier != SuperPower.PowerTier.MANDATORY
                        && power.tier != SuperPower.PowerTier.COMPOUND_V
                        && power != SuperPower.NUCLEAR_BLAST) {
                        notOwned.add(power);
                    }
                }
                if (!notOwned.isEmpty()) {
                    SuperPower newPower = notOwned.get(random.nextInt(notOwned.size()));
                    addPower(newPower);
                    lastGainedPower = newPower; // SerumV1Item mesaj için
                }
            }
        }

        CompoundVMod.LOGGER.info("V1 Serum dose {} applied! Powers: {} Amplifier: {}", v1DrinkCount, activePowers, powerAmplifier);
    }

    // Güç amplifikatörü (2. ve 3. içişte artar - PlayerEventHandler okur)
    private int powerAmplifier = 0;
    public int getPowerAmplifier() { return powerAmplifier; }

    // Son kazanılan güç (mesaj için)
    public SuperPower lastGainedPower = null;

    // ===================== NBT KAYIT =====================

    @Override
    public CompoundTag serializeNBT() {
        CompoundTag tag = new CompoundTag();
        ListTag powerList = new ListTag();
        for (SuperPower power : activePowers) {
            powerList.add(StringTag.valueOf(power.name()));
        }
        tag.put("powers", powerList);
        tag.putBoolean("powerEnabled", powerEnabled);
        tag.putBoolean("isFlying", isFlying);
        tag.putBoolean("laserActive", laserActive);
        tag.putBoolean("lightningActive", lightningActive);
        tag.putBoolean("nuclearCharged", nuclearCharged);
        tag.putFloat("sizeMultiplier", sizeMultiplier);
        tag.putInt("serumType", serumType);
        tag.putInt("v1DrinkCount", v1DrinkCount);
        tag.putInt("powerAmplifier", powerAmplifier);
        tag.putInt("nuclearChargeTicks", nuclearChargeTicks);
        tag.putInt("nuclearCooldownTicks", nuclearCooldownTicks);
        tag.putBoolean("nuclearCharging", nuclearCharging);
        tag.putInt("laserFatigueTicks", laserFatigueTicks);
        tag.putInt("lightningCooldownTicks", lightningCooldownTicks);
        return tag;
    }

    @Override
    public void deserializeNBT(CompoundTag tag) {
        activePowers.clear();
        ListTag powerList = tag.getList("powers", 8);
        for (int i = 0; i < powerList.size(); i++) {
            try {
                activePowers.add(SuperPower.valueOf(powerList.getString(i)));
            } catch (IllegalArgumentException ignored) {}
        }
        powerEnabled = tag.getBoolean("powerEnabled");
        isFlying = tag.getBoolean("isFlying");
        laserActive = tag.getBoolean("laserActive");
        lightningActive = tag.getBoolean("lightningActive");
        nuclearCharged = tag.getBoolean("nuclearCharged");
        sizeMultiplier = tag.getFloat("sizeMultiplier");
        serumType = tag.getInt("serumType");
        v1DrinkCount = tag.getInt("v1DrinkCount");
        powerAmplifier = tag.getInt("powerAmplifier");
        nuclearChargeTicks = tag.getInt("nuclearChargeTicks");
        nuclearCooldownTicks = tag.getInt("nuclearCooldownTicks");
        nuclearCharging = tag.getBoolean("nuclearCharging");
        laserFatigueTicks = tag.getInt("laserFatigueTicks");
        lightningCooldownTicks = tag.getInt("lightningCooldownTicks");
    }

    @Nonnull
    @Override
    public <T> LazyOptional<T> getCapability(@Nonnull Capability<T> cap, @Nullable Direction side) {
        return cap == CAPABILITY ? lazyOptional.cast() : LazyOptional.empty();
    }

    public void invalidate() {
        lazyOptional.invalidate();
    }

    // ===================== YARDIMCI METODLAR =====================

    public static LazyOptional<SuperPowerCapability> get(Player player) {
        return player.getCapability(CAPABILITY);
    }

    public static void register() {
        CapabilityManager.get(new CapabilityToken<SuperPowerCapability>(){});
    }

    // ===================== CAPABILITY PROVIDER =====================

    public static class Provider {

        @SubscribeEvent
        public void attachCapabilities(AttachCapabilitiesEvent<net.minecraft.world.entity.Entity> event) {
            if (event.getObject() instanceof Player) {
                SuperPowerCapability cap = new SuperPowerCapability();
                event.addCapability(ID, new ICapabilitySerializable<CompoundTag>() {
                    final LazyOptional<SuperPowerCapability> lazy = LazyOptional.of(() -> cap);

                    @Nonnull
                    @Override
                    public <T> LazyOptional<T> getCapability(@Nonnull Capability<T> capability, @Nullable Direction side) {
                        return capability == CAPABILITY ? lazy.cast() : LazyOptional.empty();
                    }

                    @Override
                    public CompoundTag serializeNBT() { return cap.serializeNBT(); }

                    @Override
                    public void deserializeNBT(CompoundTag tag) { cap.deserializeNBT(tag); }
                });
                event.addListener(cap::invalidate);
            }
        }
    }
}
