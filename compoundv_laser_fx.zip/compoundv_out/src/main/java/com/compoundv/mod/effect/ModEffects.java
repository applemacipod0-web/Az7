package com.compoundv.mod.effect;

import com.compoundv.mod.CompoundVMod;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEffects {

    public static final DeferredRegister<MobEffect> EFFECTS =
            DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, CompoundVMod.MOD_ID);

    // V1 Temel Efektleri
    public static final RegistryObject<MobEffect> NEAR_IMMORTALITY =
            EFFECTS.register("near_immortality", () -> new SuperEffect(MobEffectCategory.BENEFICIAL, 0xFF0000));

    public static final RegistryObject<MobEffect> SUPER_STRENGTH_EFFECT =
            EFFECTS.register("super_strength_effect", () -> new SuperEffect(MobEffectCategory.BENEFICIAL, 0xFF4400));

    public static final RegistryObject<MobEffect> REGENERATION_SUPER =
            EFFECTS.register("regeneration_super", () -> new SuperEffect(MobEffectCategory.BENEFICIAL, 0x00FF88));

    public static final RegistryObject<MobEffect> LIGHTNING_BUFF =
            EFFECTS.register("lightning_buff", () -> new SuperEffect(MobEffectCategory.BENEFICIAL, 0xFFFF00));
}
