package com.compoundv.mod.client;

import com.compoundv.mod.capability.SuperPowerCapability;
import com.compoundv.mod.util.SuperPower;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.ArrayList;
import java.util.List;

/**
 * Ekranın sol üst köşesinde aktif güçleri ve cooldown'ları gösterir.
 * Layout:
 *   [⚡] Güçler: Ölümsüzlük | Süper Güç | Uçma | ...
 *   [☢] Nükleer: HAZIR  /  Şarj: %40  /  Bekleme: 8:32
 *   [🔴] Lazer: AKTİF (yorgunluk ██░░░)
 *   [⚡] Yıldırım: HAZIR  /  Bekleme: 8sn
 */
@OnlyIn(Dist.CLIENT)
public class PowerHudOverlay {

    @SubscribeEvent
    public void onRenderOverlay(RenderGuiOverlayEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) return;
        // F3 ekranı açıksa HUD'u gizle
        if (mc.options.renderDebug) return;

        Player player = mc.player;
        SuperPowerCapability.get(player).ifPresent(cap -> {
            if (cap.getActivePowers().isEmpty()) return;

            GuiGraphics g = event.getGuiGraphics();
            int x = 6;
            int y = 6;
            int lineH = 10;

            // ─── Aktif güçler listesi ───
            List<String> shortNames = new ArrayList<>();
            for (SuperPower p : cap.getActivePowers()) {
                shortNames.add(shortName(p));
            }
            if (!shortNames.isEmpty()) {
                String line = "§b§lGÜÇLER: §r§f" + String.join(" §7| §f", shortNames);
                g.drawString(mc.font, line, x, y, 0xFFFFFF, true);
                y += lineH + 2;
            }

            // ─── Nükleer patlama durumu ───
            if (cap.hasPower(SuperPower.NUCLEAR_BLAST)) {
                String nucLine;
                if (cap.getNuclearCooldownTicks() > 0) {
                    int totalSecs = cap.getNuclearCooldownTicks() / 20;
                    int mins = totalSecs / 60;
                    int secs = totalSecs % 60;
                    nucLine = "§c☢ Nükleer: §7Bekleme §e" + mins + ":" + String.format("%02d", secs);
                } else if (cap.isNuclearCharging()) {
                    int pct = cap.getNuclearChargeTicks() / 10;
                    String bar = progressBar(pct, 100, 10);
                    nucLine = "§6☢ Nükleer: §eŞarj %" + pct + " " + bar;
                } else {
                    nucLine = "§a☢ Nükleer: HAZIR §7(Z basılı tut)";
                }
                g.drawString(mc.font, nucLine, x, y, 0xFFFFFF, true);
                y += lineH;
            }

            // ─── Lazer göz durumu ───
            if (cap.hasPower(SuperPower.LASER_EYES) || cap.hasPower(SuperPower.V24_LASER)) {
                String lazerLine;
                int fatigue = cap.getLaserFatigueTicks();
                if (cap.isLaserActive()) {
                    int pct = Math.min(fatigue, 100);
                    String bar = progressBar(pct, 100, 8);
                    lazerLine = "§c🔴 Lazer: §lAKTİF §r" + bar;
                } else if (fatigue > 0) {
                    int recoverSecs = (fatigue / 2 / 20) + 1;
                    lazerLine = "§7🔴 Lazer: Dinleniyor §e(" + recoverSecs + "sn)";
                } else {
                    lazerLine = "§a🔴 Lazer: HAZIR §7(H)";
                }
                g.drawString(mc.font, lazerLine, x, y, 0xFFFFFF, true);
                y += lineH;
            }

            // ─── Stormfront yıldırım durumu ───
            if (cap.hasPower(SuperPower.LIGHTNING_CONTROL)) {
                String ltLine;
                if (cap.getLightningCooldownTicks() > 0) {
                    int secs = (cap.getLightningCooldownTicks() / 20) + 1;
                    ltLine = "§7⚡ Yıldırım: §eBekleme " + secs + "sn";
                } else {
                    ltLine = "§e⚡ Yıldırım: HAZIR §7(N)";
                }
                g.drawString(mc.font, ltLine, x, y, 0xFFFFFF, true);
                y += lineH;
            }

            // ─── Uçma durumu ───
            if (cap.hasPower(SuperPower.FLIGHT)) {
                String flyLine = cap.isFlying()
                    ? "§a✈ Uçuş: §lAKTİF"
                    : "§7✈ Uçuş: kapalı §7(G)";
                g.drawString(mc.font, flyLine, x, y, 0xFFFFFF, true);
                y += lineH;
            }
        });
    }

    /** Kısa isim etiketleri */
    private String shortName(SuperPower p) {
        return switch (p) {
            case NEAR_IMMORTALITY   -> "§cÖlümsüzlük";
            case SUPER_STRENGTH     -> "§cSüper Güç";
            case FLIGHT             -> "§bUçma";
            case SUPER_SPEED        -> "§eA-Train";
            case LASER_EYES         -> "§cLazer";
            case V24_LASER          -> "§cV24 Lazer";
            case LIGHTNING_CONTROL  -> "§eYıldırım";
            case ELECTROMAGNETIC    -> "§9EM Alan";
            case REGENERATION       -> "§aYenilenme";
            case STORMFRONT_SHIELD  -> "§9Kalkan";
            case NUCLEAR_BLAST      -> "§6Nükleer";
            case SOLDIER_SIZE       -> "§6Soldier";
            default                 -> "§7" + p.displayName;
        };
    }

    /** ASCII ilerleme çubuğu */
    private String progressBar(int current, int max, int width) {
        int filled = (int) Math.round((double) current / max * width);
        filled = Math.max(0, Math.min(filled, width));
        StringBuilder sb = new StringBuilder("§8[");
        for (int i = 0; i < width; i++) {
            sb.append(i < filled ? "§e█" : "§8░");
        }
        sb.append("§8]");
        return sb.toString();
    }
}
