package com.compoundv.mod.network;

import com.compoundv.mod.CompoundVMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

public class PacketHandler {

    private static final String PROTOCOL_VERSION = "1";
    private static int ID = 0;

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(CompoundVMod.MOD_ID, "main"),
            () -> PROTOCOL_VERSION,
            PROTOCOL_VERSION::equals,
            PROTOCOL_VERSION::equals
    );

    public static void register() {
        CHANNEL.registerMessage(ID++, KeyActionPacket.class,
                KeyActionPacket::encode, KeyActionPacket::decode, KeyActionPacket::handle);

        CHANNEL.registerMessage(ID++, SyncPowersPacket.class,
                SyncPowersPacket::encode, SyncPowersPacket::decode, SyncPowersPacket::handle);

        CHANNEL.registerMessage(ID++, NuclearBlastPacket.class,
                NuclearBlastPacket::encode, NuclearBlastPacket::decode, NuclearBlastPacket::handle);

        CHANNEL.registerMessage(ID++, TrampleParticlePacket.class,
                TrampleParticlePacket::encode, TrampleParticlePacket::decode, TrampleParticlePacket::handle);
    }
}
